#!/bin/sh
source ./_env.sh
docker build -t $TAG .
